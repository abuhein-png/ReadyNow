# READY NOW – Android (real Bluetooth/Wi-Fi mesh)

Native Kotlin + Jetpack Compose. Uses Google Nearby Connections
(BLE discovery, Bluetooth + Wi-Fi transport, P2P_CLUSTER).

## Build
1. Android Studio (Koala or newer) -> Open this folder -> let Gradle sync.
   (If the wrapper jar is missing, Studio regenerates it, or run `gradle wrapper`.)
2. Run on REAL phones (emulators have no Bluetooth). Need Android 8+ with Google Play services.

## Test (needs 2+ phones)
1. Install on both. Open app -> Settings -> grant permissions -> turn on the mesh.
2. Phone A: hold SOS for 2 seconds. Phone B should show it in the feed and notify.
3. Multi-hop: with 3 phones A-B-C, place A and C out of each other's range (different
   rooms/floors) with B between them. A's SOS should reach C through B.
4. Store-and-forward: send from A while alone, then bring B near: B receives the backlog.

## How it works
- Mesh.kt: message model, persisted log (last 200), dedupe by id, hop budget (8).
- MeshService.kt: foreground service; advertise+discover; auto-accept; flood relay
  (forward to all peers except sender, hops-1); backlog sent to each new neighbour.
- MainActivity.kt: Home (status, hold-to-SOS, "I am OK", chat, feed) and
  Settings (live Bluetooth / Wi-Fi / location / permissions / battery / Play services checks).

## Known limits
- Not compiled or field-tested by the author. Expect small fixes on first build.
- Android only. iOS needs a different stack (Multipeer Connectivity) and cannot talk to this one.
- Nearby gives no signal strength, so no "getting warmer" locate yet; location is
  the sender's last known GPS fix only.
- Relays can read messages (link encryption only). Add end-to-end encryption before real use.
- Not a replacement for official emergency services or certified rescue equipment.
