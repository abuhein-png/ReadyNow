package com.readynow.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** kind: SOS | OK | MSG. hops = remaining relays allowed. */
data class Msg(
    val id: String, val from: String, val ts: Long, val kind: String, val text: String,
    val lat: Double?, val lon: Double?, val hops: Int
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("o", from).put("t", ts)
        .put("k", kind).put("x", text).put("h", hops).apply {
            if (lat != null && lon != null) { put("la", lat); put("lo", lon) }
        }

    companion object {
        fun parse(s: String): Msg? = try {
            val j = JSONObject(s)
            Msg(
                j.getString("id"), j.getString("o"), j.getLong("t"), j.getString("k"), j.optString("x"),
                if (j.has("la")) j.getDouble("la") else null,
                if (j.has("lo")) j.getDouble("lo") else null, j.getInt("h")
            )
        } catch (e: Exception) { null }
    }
}

/** Shared state between the UI and MeshService, plus the persisted message store. */
object Mesh {
    const val SERVICE_ID = "com.readynow.app.mesh"
    const val MAX_HOPS = 8

    val running = MutableStateFlow(false)
    val status = MutableStateFlow("متوقفة")
    val peers = MutableStateFlow<List<String>>(emptyList())
    val log = MutableStateFlow<List<Msg>>(emptyList())
    @Volatile var service: MeshService? = null

    private lateinit var prefs: SharedPreferences
    private val seen = HashSet<String>()

    fun init(ctx: Context) {
        if (::prefs.isInitialized) return
        prefs = ctx.applicationContext.getSharedPreferences("mesh", Context.MODE_PRIVATE)
        val arr = try { JSONArray(prefs.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        val list = (0 until arr.length()).mapNotNull { Msg.parse(arr.getString(it)) }
        list.forEach { seen.add(it.id) }
        log.value = list
    }

    var alias: String
        get() = prefs.getString("alias", "") ?: ""
        set(v) { prefs.edit().putString("alias", v.take(30)).apply() }

    var includeLoc: Boolean
        get() = prefs.getBoolean("loc", true)
        set(v) { prefs.edit().putBoolean("loc", v).apply() }

    private val uid: String
        get() = prefs.getString("uid", null)
            ?: UUID.randomUUID().toString().take(4).also { prefs.edit().putString("uid", it).apply() }

    /** Unique, stable name used as the Nearby endpoint name. */
    val endpointName: String get() = alias.ifBlank { "مجهول" } + "#" + uid

    @Synchronized
    fun add(m: Msg): Boolean {
        if (!seen.add(m.id)) return false
        val l = (log.value + m).sortedBy { it.ts }.takeLast(200)
        log.value = l
        prefs.edit().putString("log", JSONArray(l.map { it.toJson().toString() }).toString()).apply()
        return true
    }

    /** The copy to forward: own messages as-is, others with one hop consumed (null = stop). */
    fun outgoing(m: Msg): Msg? =
        if (m.from == endpointName) m else if (m.hops > 0) m.copy(hops = m.hops - 1) else null

    fun post(kind: String, text: String, lat: Double?, lon: Double?) {
        val m = Msg(UUID.randomUUID().toString(), endpointName, System.currentTimeMillis(), kind, text, lat, lon, MAX_HOPS)
        add(m)
        service?.send(m, null)
    }
}
