package com.readynow.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.GoogleApiAvailability
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Mesh.init(this)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) { App() }
            }
        }
    }
}

private val RED = Color(0xFFD92D2D)
private val GREEN = Color(0xFF2E9E6B)

// ---------- permissions & helpers ----------
fun corePerms(): List<String> {
    val l = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
    if (Build.VERSION.SDK_INT >= 31) l.addAll(listOf(
        Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.BLUETOOTH_CONNECT))
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.NEARBY_WIFI_DEVICES)
    return l
}
fun Context.missingCore(): List<String> =
    corePerms().filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
fun Context.missingAll(): List<String> {
    val l = missingCore().toMutableList()
    if (Build.VERSION.SDK_INT >= 33 &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
        l.add(Manifest.permission.POST_NOTIFICATIONS)
    return l
}
fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()

fun setMesh(ctx: Context, on: Boolean) {
    if (on) ContextCompat.startForegroundService(ctx, Intent(ctx, MeshService::class.java))
    else ctx.startService(Intent(ctx, MeshService::class.java).setAction(MeshService.ACTION_STOP))
}

/** Posts a message with the last known GPS fix (if allowed and available). */
@SuppressLint("MissingPermission")
fun postWithLocation(ctx: Context, kind: String, text: String) {
    val allowed = Mesh.includeLoc &&
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    if (!allowed) { Mesh.post(kind, text, null, null); return }
    LocationServices.getFusedLocationProviderClient(ctx).lastLocation
        .addOnSuccessListener { Mesh.post(kind, text, it?.latitude, it?.longitude) }
        .addOnFailureListener { Mesh.post(kind, text, null, null) }
}

// ---------- root ----------
@Composable
fun App() {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (ctx.missingCore().isEmpty()) setMesh(ctx, true) else toast(ctx, "الأذونات مطلوبة لتشغيل الشبكة")
    }
    val start: () -> Unit = {
        if (ctx.missingCore().isEmpty()) setMesh(ctx, true) else launcher.launch(ctx.missingAll().toTypedArray())
    }
    val ask: () -> Unit = { val m = ctx.missingAll(); if (m.isNotEmpty()) launcher.launch(m.toTypedArray()) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Text("⚙") }, label = { Text("الإعدادات") })
        }
    }) { pad ->
        Box(Modifier.padding(pad)) { if (tab == 0) HomeScreen(start) else SettingsScreen(start, ask) }
    }
}

// ---------- home ----------
@Composable
fun HomeScreen(start: () -> Unit) {
    val ctx = LocalContext.current
    val running by Mesh.running.collectAsState()
    val status by Mesh.status.collectAsState()
    val peers by Mesh.peers.collectAsState()
    val log by Mesh.log.collectAsState()
    var text by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("READY NOW", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(status, fontWeight = FontWeight.Bold)
                    Text(if (peers.isEmpty()) "لا أجهزة متصلة" else "متصل بـ: " + peers.joinToString("، "))
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { if (running) setMesh(ctx, false) else start() }) {
                        Text(if (running) "إيقاف الشبكة" else "تشغيل شبكة الإنقاذ")
                    }
                }
            }
        }
        item { SosButton() }
        item {
            OutlinedButton(onClick = {
                postWithLocation(ctx, "OK", "أنا بخير")
                toast(ctx, if (running) "أُرسلت الرسالة" else "الشبكة متوقفة: حُفظت وستُرسل عند تشغيلها")
            }, Modifier.fillMaxWidth()) { Text("أنا بخير") }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("رسالة قصيرة") }, maxLines = 3)
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (text.isNotBlank()) { postWithLocation(ctx, "MSG", text.trim()); text = "" }
                }) { Text("إرسال") }
            }
        }
        items(log.reversed(), key = { it.id }) { MsgCard(it) }
    }
}

@Composable
fun SosButton() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var p by remember { mutableFloatStateOf(0f) }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(150.dp).clip(CircleShape).background(RED).pointerInput(Unit) {
                detectTapGestures(onPress = {
                    val job = scope.launch {
                        val t0 = System.currentTimeMillis()
                        while (p < 1f) { p = ((System.currentTimeMillis() - t0) / 2000f).coerceAtMost(1f); delay(16) }
                        postWithLocation(ctx, "SOS", "استغاثة عاجلة")
                        toast(ctx, if (Mesh.running.value) "أُرسلت الاستغاثة إلى الأجهزة القريبة"
                        else "الشبكة متوقفة: حُفظت الاستغاثة وستُرسل عند تشغيلها")
                    }
                    tryAwaitRelease(); job.cancel(); p = 0f
                })
            },
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(progress = { p }, Modifier.fillMaxSize().padding(6.dp),
                color = Color.White, strokeWidth = 6.dp, trackColor = Color.Transparent)
            Text("SOS", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun MsgCard(m: Msg) {
    val ctx = LocalContext.current
    val sos = m.kind == "SOS"
    val who = if (m.from == Mesh.endpointName) "أنا" else m.from.substringBeforeLast('#')
    val tag = when (m.kind) { "SOS" -> "استغاثة"; "OK" -> "بخير"; else -> "رسالة" }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(
        containerColor = if (sos) Color(0x33D92D2D) else MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(12.dp)) {
            Text("$tag • $who • " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.ts)), fontWeight = FontWeight.Bold)
            Text(m.text)
            if (m.lat != null && m.lon != null) TextButton(onClick = {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${m.lat},${m.lon}?q=${m.lat},${m.lon}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) { toast(ctx, "لا يوجد تطبيق خرائط") }
            }) { Text("آخر موقع معروف (قد يكون قديماً)") }
        }
    }
}

// ---------- settings ----------
@Composable
fun StatusRow(title: String, ok: Boolean, hint: String, action: String? = null, onClick: () -> Unit = {}) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).clip(CircleShape).background(if (ok) GREEN else RED))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(hint, fontSize = 13.sp) }
            if (!ok && action != null) TextButton(onClick = onClick) { Text(action) }
        }
    }
}

@Composable
fun SettingsScreen(start: () -> Unit, ask: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(ob); onDispose { owner.lifecycle.removeObserver(ob) }
    }
    val running by Mesh.running.collectAsState()
    var inc by remember { mutableStateOf(Mesh.includeLoc) }
    var alias by remember { mutableStateOf(Mesh.alias) }

    val bt = tick.let { ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true }
    val wifi = tick.let { (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled }
    val loc = tick.let { LocationManagerCompat.isLocationEnabled(ctx.getSystemService(LocationManager::class.java)) }
    val perms = tick.let { ctx.missingCore().isEmpty() }
    val batt = tick.let { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) }
    val gms = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx) == ConnectionResult.SUCCESS

    fun open(action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { toast(ctx, "تعذر فتح الإعدادات") }
    }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("إعدادات الاتصال", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("شبكة الإنقاذ", fontWeight = FontWeight.Bold)
                        Text(if (running) "تعمل في الخلفية" else "متوقفة", fontSize = 13.sp)
                    }
                    Switch(checked = running, onCheckedChange = { if (it) start() else setMesh(ctx, false) })
                }
            }
        }
        item { StatusRow("البلوتوث", bt, if (bt) "مفعّل" else "مغلق: فعّله ليعمل الاكتشاف", "فتح") { open(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS) } }
        item { StatusRow("واي فاي", wifi, if (wifi) "مفعّل (يُستخدم لنقل أسرع)" else "مغلق: يعمل البلوتوث وحده لكن أبطأ", "فتح") { open(android.provider.Settings.ACTION_WIFI_SETTINGS) } }
        item { StatusRow("خدمات الموقع", loc, if (loc) "مفعّلة" else "مغلقة: تلزم للاكتشاف في بعض الأجهزة", "فتح") { open(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS) } }
        item { StatusRow("الأذونات", perms, if (perms) "ممنوحة" else "ناقصة: بلوتوث وأجهزة قريبة وموقع", "منح") { ask() } }
        item { StatusRow("توفير البطارية", batt, if (batt) "التطبيق مستثنى" else "قد يوقف النظام الشبكة في الخلفية", "استثناء") { open(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) } }
        item { StatusRow("خدمات Google Play", gms, if (gms) "متوفرة" else "غير متوفرة: لن تعمل Nearby على هذا الجهاز") }
        item {
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("إرفاق آخر موقع معروف", fontWeight = FontWeight.Bold)
                        Text("يُضاف إلى الاستغاثة ويراه كل من تصله", fontSize = 13.sp)
                    }
                    Switch(checked = inc, onCheckedChange = { inc = it; Mesh.includeLoc = it })
                }
            }
        }
        item {
            OutlinedTextField(alias, { alias = it.take(30); Mesh.alias = alias }, Modifier.fillMaxWidth(),
                label = { Text("اسمك الظاهر للآخرين") }, singleLine = true,
                supportingText = { Text("أعد تشغيل الشبكة بعد التغيير") })
        }
        item {
            Text("ملاحظات: المدى بضع عشرات من الأمتار وقد يقل كثيراً خلف الجدران والركام. " +
                "الرسائل مشفّرة بين كل جهازين متصلين لكن الأجهزة الوسيطة تستطيع قراءتها. " +
                "التطبيق لا يحدد موقعاً دقيقاً لشخص مدفون، ولا يغني عن الاتصال بالطوارئ عند توفر الشبكة.",
                fontSize = 13.sp)
        }
    }
}
