package com.readynow.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.util.concurrent.ConcurrentHashMap

/**
 * Real offline mesh: Nearby Connections (BLE discovery + Bluetooth/Wi-Fi transport),
 * P2P_CLUSTER topology, flood relay with hop limit, de-duplication and store-and-forward.
 */
class MeshService : Service() {
    companion object { const val ACTION_STOP = "com.readynow.app.STOP" }

    private lateinit var client: ConnectionsClient
    private val names = ConcurrentHashMap<String, String>()
    private val peers = ConcurrentHashMap<String, String>()
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private var started = false

    override fun onCreate() {
        super.onCreate()
        Mesh.init(this)
        client = Nearby.getConnectionsClient(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mesh", "شبكة الإنقاذ", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("sos", "استغاثات واردة", NotificationManager.IMPORTANCE_HIGH))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopMesh(); stopSelf(); return START_NOT_STICKY }
        val n = NotificationCompat.Builder(this, "mesh")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("READY NOW").setContentText("شبكة الإنقاذ تعمل").setOngoing(true).build()
        try {
            val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE else 0
            ServiceCompat.startForeground(this, 1, n, type)
        } catch (e: Exception) {
            Mesh.status.value = "تعذر التشغيل: ${e.message}"; stopSelf(); return START_NOT_STICKY
        }
        Mesh.service = this
        startMesh()
        return START_STICKY
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { stopMesh(); super.onDestroy() }

    private fun startMesh() {
        if (started) return
        started = true
        val strat = Strategy.P2P_CLUSTER
        client.startAdvertising(Mesh.endpointName, Mesh.SERVICE_ID, connCb,
            AdvertisingOptions.Builder().setStrategy(strat).build())
            .addOnSuccessListener { Mesh.running.value = true; pushPeers() }
            .addOnFailureListener { Mesh.running.value = false; Mesh.status.value = "فشل البث: ${it.message}" }
        client.startDiscovery(Mesh.SERVICE_ID, discCb,
            DiscoveryOptions.Builder().setStrategy(strat).build())
            .addOnFailureListener { Mesh.status.value = "فشل البحث: ${it.message}" }
    }

    private fun stopMesh() {
        if (::client.isInitialized) {
            client.stopAdvertising(); client.stopDiscovery(); client.stopAllEndpoints()
        }
        peers.clear(); names.clear(); pending.clear(); started = false
        Mesh.running.value = false; Mesh.peers.value = emptyList(); Mesh.status.value = "متوقفة"
        Mesh.service = null
    }

    private fun pushPeers() {
        Mesh.peers.value = peers.values.map { it.substringBeforeLast('#') }
        Mesh.status.value = if (peers.isEmpty()) "تعمل: تبحث عن أجهزة قريبة" else "متصلة بـ ${peers.size} جهاز"
    }

    fun send(m: Msg, except: String?) {
        val ids = peers.keys.filter { it != except }
        if (ids.isNotEmpty()) client.sendPayload(ids, Payload.fromBytes(m.toJson().toString().toByteArray()))
    }

    private val discCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            if (peers.containsKey(id) || !pending.add(id)) return
            client.requestConnection(Mesh.endpointName, id, connCb).addOnFailureListener { pending.remove(id) }
        }
        override fun onEndpointLost(id: String) { pending.remove(id) }
    }

    private val connCb = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            names[id] = info.endpointName
            client.acceptConnection(id, payloadCb)
        }
        override fun onConnectionResult(id: String, r: ConnectionResolution) {
            pending.remove(id)
            if (r.status.isSuccess) {
                peers[id] = names[id] ?: id
                pushPeers()
                // store-and-forward: hand the new neighbour everything still worth relaying
                Mesh.log.value.takeLast(50).mapNotNull { Mesh.outgoing(it) }.forEach {
                    client.sendPayload(id, Payload.fromBytes(it.toJson().toString().toByteArray()))
                }
            }
        }
        override fun onDisconnected(id: String) { peers.remove(id); pending.remove(id); pushPeers() }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, p: Payload) {
            val m = p.asBytes()?.toString(Charsets.UTF_8)?.let { Msg.parse(it) } ?: return
            if (!Mesh.add(m)) return                 // already seen: stop loops
            if (m.kind == "SOS") notifySos(m)
            Mesh.outgoing(m)?.let { send(it, id) }   // relay to everyone except the sender
        }
        override fun onPayloadTransferUpdate(id: String, u: PayloadTransferUpdate) {}
    }

    private fun notifySos(m: Msg) {
        val tap = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "sos").setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("استغاثة قريبة")
            .setContentText(m.from.substringBeforeLast('#') + ": " + m.text)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(tap).build()
        getSystemService(NotificationManager::class.java).notify(m.id.hashCode(), n)
    }
}
